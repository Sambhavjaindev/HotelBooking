<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>THBS</title>
    <link rel="stylesheet" href="SIGNUP.css">
    <link href="https://fonts.googleapis.com/css?family=Permanent+Marker" rel="stylesheet">
  </head>
  <body>
    <div class="signup-form">
      <form class="" action="thankyou.php" method="post">
        <h1>PAYMENT PAGE</h1>

 

        <input type="text" placeholder="Card Holder Name" pattern="[A-Za-z\s]{3,50}" title="Enter Valid Name" class="txtb" required>

 

        <input type="text" placeholder="Card Number" pattern="[4-6]{1}[0-9]{3}[0-9]{4}[0-9]{4}[0-9]{4}" title="Enter 16 digit Valid Card Number" class="txtb" required>

 

        <h3>Expiry Date</h3>
        <input type="month" placeholder="Exp Date" class="txtb" required>

 

        <input type="text" placeholder="CVV"  pattern="[0-9]{3}" title="Wrong CVV" class="txtb" required>

 

        <input type="submit" value="BOOK" class="signup-btn">
      </form>
    </div>

  </body>
</html>