<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Hotel Booking</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
   
    
    <style>
        .well
        {
            background: rgba(0,0,0,0.7);
            border: none;
    
        }
        .wellfix
        {
            background: rgba(0,0,0,0.7);
            border: none;
            height: 150px;
        }
		body
		{
			background-image: url('images/home_bg.jpg');
			background-repeat: no-repeat;
			background-attachment: fixed;
		}
		p
		{
			font-size: 13px;
		}
        .pro_pic
        {
            border-radius: 50%;
            height: 50px;
            width: 50px;
            margin-bottom: 15px;
            margin-right: 15px;
        }
		
    </style>
    
    
</head>

<body>
    <div class="container">
      
      
       <img class="img-responsive" src="images/home_banner.jpg" style="width:100%; height:180px;">      
       <nav class="navbar navbar-inverse">
            <div class="container-fluid">
                <ul class="nav navbar-nav">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="room.php">Room &amp; Facilities</a>
                    <li class="active"><a href="review.php">Review</a></li>
                    <li><a href="admin.php">Admin</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                     <li><a href="https://www.facebook.com/TorryHarrisIntegrationSolutions/"><img src="images/facebook.png"></a></li>
                    <li><a href="https://twitter.com/torryharris"><img src="images/twitter.png"></a></li>                   
                </ul>
            </div>
        </nav>


     
        
        <hr>
        <div class="row" style="color: #ed9e21">
            <div class="col-md-12 well" >
              <h3><strong style="color: #ffbb2b">Customer Feedback</strong></h3><br>
                 <h4><strong style="color: #ffbb2b">Amar , Karnataka</strong></h4><br>
                <p>Nice Place</p>
              <p>"Hospitality, kindness, cleanliness ans service were there as expected. I can only advise you to continue this way same if it would be nice to offer some croissants and pains au chocolats at the breakfast� </p><br>
                
                <h4><strong style="color: #ffbb2b">Akbar , Mumbai</strong></h4><br>
                <p>We Loved it</p>
              <p>"The hotel room was clean, nice and spacious. Breakfast offered with a wide variety of food. The staff were friendly and helpful. The location is just perfect for a walk around the city centre.</p><br>
                
                <h4><strong style="color: #ffbb2b">Antony , Punjab</strong></h4><br>
                <p>Comfortable Living</p>
              <p>"Can be easily reached and most of the shopping centers and sights are nearby. The room was comfortable and I'm a big fan of scandinavian bathroom structures, they are very practical altogether. </p><br>
                
                
              
              
            </div>  
        </div>
        <div class="row" style="color: #ffbb2b">
            <div class="col-md-4 wellfix">
              <h4><strong>Contact Us</strong></h4><hr>
              Address :  Mysore Rd, RR Nagar, Bengaluru, Karnataka 560059<br>
              Mail : torry_harris@thbs.com <br>
            </div>
            <div class="col-md-4"></div>
            
        </div>
        



    </div>
    
    
    
    
    




    <script src="my_js/slide.js"></script>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
</body>

</html>