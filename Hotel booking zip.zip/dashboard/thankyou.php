<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>HOTEL BOOKING</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="main.css">
        <script src="https://kit.fontawesome.com/dbed6b6114.js" crossorigin="anonymous"></script>
        
    </head>
    <body>
        
        <!-- header -->
        <header class = "header" id = "header">
            <div class = "head-top">
                <div class = "site-name">
  <a href="index.php">
      <input type="submit" value="HOME"/>
    </a>
                   
                </div>

 

            </div>

 

            <div class = "head-bottom flex">
                <h2>THANK YOU</h2>
                <p>For Booking Your Stay In Our Hotel</p>
                
            </div>
        </header>
  
        
      
    </body>
</html>